# 1. How to Make
- Got to HW2/src/
- Enter `make`
- Go to run

# 2. How to Run
- Go to HW2/bin/
- Use `./hw2 input.file output.file timelimit maxG` to run
    - maxG is the partial sum, if smaller than maxG then stop and output
    - example: `/hw2 ../testcase/public6.txt ../output/public6.out 1000 200`
    - example: `/hw2_parallel ../testcase/public6.txt ../output/public6.out 1000 200`