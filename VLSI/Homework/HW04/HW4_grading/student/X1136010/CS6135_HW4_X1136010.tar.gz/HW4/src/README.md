# Readme for HW4

- Under `HW4/src`
    - `make grade` : Grade the program using `HW4_grading.sh` that stated in document