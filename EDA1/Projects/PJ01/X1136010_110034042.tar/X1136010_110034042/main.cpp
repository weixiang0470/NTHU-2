#include <iostream>
#include <unordered_map>
#include <string>
#include <sstream>
#include <fstream>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <chrono>

using namespace std;

const int INF = 1e9;
int n;
vector<vector<int>> memo;
vector<vector<int>> parent2;


map<int,vector<pair<int,int>>> Nodes; // node:{neighbour, weight} 

// Functions_Print
void Print_AM(vector<vector<int>>& cities, ofstream& outfile);
void Print_Nodes_Edges();

// Solver
class TSP_TopDown{
    private:
        int MinCost;
        int TSP(int mask, int now_city,const vector<vector<int>>& cost);
        void Print_OPTPath(vector<vector<int>> parents, ofstream& outfile);

    public:
        TSP_TopDown(vector<vector<int>> cities, ofstream& outfile){
            Solve(cities, outfile);
        };
        void Solve(vector<vector<int>> cities, ofstream& outfile){
            MinCost = TSP(1,0,cities);
            if (MinCost >= INF) {
                outfile << "Unable to form Hamilton cycle (tour path)." << endl;
                return;
            }
            outfile<<"Total Distance: "<< MinCost << endl;
            Print_OPTPath(parent2, outfile);
        }
};

void TSP_BottomUP(const vector<vector<int>>& cost, ofstream& outfile);


int main(int argc, char* argv[]) {
   
	if(argc < 3){
        cerr<<"Method: "<< argv[0] << " intput_file output_file"<<endl;
	return 1;
    }
	ifstream infile(argv[1]);
	if (!infile.is_open()){
		cerr << "Unable to open input file: "<< argv[1] <<endl;
	return 1;
	}
    ofstream outfile(argv[2]);
    if (!outfile.is_open()) {
        cerr << "Unable to open output file: " << argv[2] << endl;
        return 1;
    }
	
    // Read input file
	string line;
	while(getline(infile,line)){
        if (line.empty() || line[0] == '#') continue;
		istringstream iss(line);
		string edge;
		int weight;
		string v1,v2;

		if(!(iss>>edge>>weight>>v1>>v2)){
			cerr<<"Error format: "<<line<<endl;
            cerr<<"Correct format: # edgeIndex  edgeWeight  nameOfVertexU  nameOfVertexV"<<endl;
			continue;		
        }
        int n1 = stoi(v1.substr(1)) -1;
        int n2 = stoi(v2.substr(1)) -1;
        Nodes[n1].push_back({n2,weight});
        Nodes[n2].push_back({n1,weight});
}	
	infile.close();
	
    // Construct Adjacency Matrix
    vector<vector<int>> cities(Nodes.size(),vector<int>(Nodes.size(),INF));
    for(const auto& node : Nodes){
        for (const auto& neighbor : node.second){
            cities[node.first][neighbor.first] =  neighbor.second;
            cities[neighbor.first][node.first] =  neighbor.second;
        }
    }

    // Output relevant information
    n = cities.size();
    outfile <<"Number of cities: "<< n <<endl;
    Print_AM(cities, outfile);
    
    memo.assign(1 << n, vector<int>(n, -1));
    parent2.assign(1 << n, vector<int>(n, -1));

    // Solve (Top-down approach)
    outfile << "\nTop-down approach: " << endl;
    auto start_td = chrono::high_resolution_clock::now();  // start
    TSP_TopDown solver_(cities, outfile);
    auto end_td = chrono::high_resolution_clock::now();  // end
    chrono::duration<double> elapsed_td = end_td - start_td;
    outfile << "Execution Time: " << elapsed_td.count() << " seconds" << endl;
    cout << "Execution Time (Top-Down): " << elapsed_td.count() << " seconds" << endl;

    // Solve (Bottom-up approach)
    outfile << "\nBottom-up approach: " << endl;
    auto start_bu = chrono::high_resolution_clock::now();  // start
    TSP_BottomUP(cities, outfile);
    auto end_bu = chrono::high_resolution_clock::now();  // end
    chrono::duration<double> elapsed_bu = end_bu - start_bu;
    outfile << "Execution Time: " << elapsed_bu.count() << " seconds" << endl;
    cout << "Execution Time (Bottom-Up): " << elapsed_bu.count() << " seconds" << endl;

    return 0;
}


void Print_AM(vector<vector<int>>& cities, ofstream& outfile){
    outfile << "Adjacency Matrix:" <<endl;
    int width = 5;
    outfile << setw(width) <<" ";
    for(int i=0;i<cities.size();++i){
        string tmp = "v"; 
        outfile<< setw(width) << tmp.append(to_string(i+1));
    }
    outfile<<endl;
    for(int i=0;i<cities.size();++i){
        // outfile<< setw(width) << "v" << (i+1);
        string tmp = "v"; 
        outfile<< setw(width) << tmp.append(to_string(i+1));
        for(int j=0;j<cities[i].size();++j){
            if (cities[i][j] == INF)
                outfile<< setw(width) <<"INF";
            else
                outfile<< setw(width) <<cities[i][j];
        }
        outfile<<endl;
    }
}

void Print_Nodes_Edges(){
    for (const auto &kv : Nodes) {
        cout << "Node " << kv.first << " has neighbors: ";
        for (const auto &neighbor : kv.second) {
            cout << "(" << neighbor.first << ", weigth = " << neighbor.second << ") ";
        }
        cout << endl;
    }
	// for (const auto& entry : Edges_dict){
	// 	cout<<entry.first<<" "<<entry.second.first<<" "<<entry.second.second.first<<" "<<entry.second.second.second<<endl;
    // }
}

void TSP_TopDown::Print_OPTPath(vector<vector<int>> parents, ofstream& outfile) {
    int mask = 1, i = 0; // Start from node 0 (v1)
    outfile << "Optimal Path: v1 -> ";
    while (true) {
        int next = parents[mask][i];
        if (next == -1) break;
        outfile <<"v"<< to_string(next+1) << " -> ";
        mask |= (1 << next);
        i = next;
    }
    outfile << "v1" << endl; // Back to start
}

int TSP_TopDown::TSP(int mask, int now_city,const vector<vector<int>>& cost){
    // If all cities visited, return to origin city;
    if (mask == (1<<n)- 1) return cost[now_city][0];
    // If the route to city is calculated, then return the cost
    if (memo[mask][now_city] != -1) return memo[mask][now_city];

    int minCost = INF;
    int bestNext = -1;

    for(int i=0;i<n;i++){
        if( !(mask & (1<<i)) ){
            int newMask = mask | (1<<i);
            int newCost = cost[now_city][i] + TSP(newMask,i,cost);

            if(newCost < minCost){
                minCost = newCost;
                bestNext = i;
            }
        }
    }
    parent2[mask][now_city] = bestNext;
    return memo[mask][now_city] = minCost;
}

void TSP_BottomUP(const vector<vector<int>>& cost, ofstream& outfile){
    /* dp[mask][i] means starting from the starting point (assumed to be node 0), 
    the minimum cost to visit all cities in mask and finally arrive at node i */
    int N = 1 << n;
    vector<vector<int>> dp(N, vector<int>(n, INF));
    vector<vector<int>> parent(N, vector<int>(n, -1));
    
    // Initial：Visit the starting point，cost = 0
    dp[1][0] = 0;

    // Traverse all states
    for (int mask = 1; mask < N; mask++) {
        for (int i = 0; i < n; i++) {
            if (!(mask & (1 << i))) continue; // Skip if node i is not in mask
            if (dp[mask][i] == INF) continue; // Skip if current state is unreachable
            // Try to expand to city j that has not been visited yet j
            for (int j = 0; j < n; j++) {
                if (mask & (1 << j)) continue; // Skip if j has been visited
                int nextMask = mask | (1 << j);
                int newCost = dp[mask][i] + cost[i][j];
                if (newCost < dp[nextMask][j]){
                    dp[nextMask][j] = newCost;
                    parent[nextMask][j] = i; // Record the best source city
                }
            }
        }
    }
    
    // Find the shortest path back to node 0
    int lastCity = -1, minCost = INF;
    for (int i = 0; i < n; i++) {
        int totalCost = dp[N - 1][i] + cost[i][0];
        if (totalCost < minCost) {
            minCost = totalCost;
            lastCity = i;
        }
    }

    if (minCost >= INF) {
        outfile << "Unable to form Hamilton cycle (tour path)." << endl;
        return;
    } else {
        outfile << "Total Distance: " << minCost << endl;
    }
    // Backtracking path
    vector<int> path;
    int mask = N - 1;
    while (lastCity != -1) {
        path.push_back(lastCity);
        int prevCity = parent[mask][lastCity];
        mask ^= (1 << lastCity); // Remove lastCity
        lastCity = prevCity;
    }
    reverse(path.begin(), path.end());

    outfile << "Optimal Path: ";
    for (int city : path) {
        outfile << "v"<< to_string(city+1) << " -> ";
    }
    outfile << "v1" << endl;
    return;
}