#define DATA_LENGTH 22
#define FLIT_LENGTH 32

#define HEAD "00"
#define BODY "01"
#define TAIL "10"

#define NoC_size 3

