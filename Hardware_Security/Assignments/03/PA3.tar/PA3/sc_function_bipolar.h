#include <stdlib.h>
#include <time.h>
#include <cstdlib>
#include <string>
#include <iostream>
#include <math.h>
#include <algorithm>
#include <vector>

using namespace std;

float bipolar_mul(float input1, float input2, int bit_stream_length) {
    /*******************************/
    // input1
    // Generate no repeated random number
    /**Complete your Design**/

    // Transfer the binary number to bit stream
    /**Complete your Design**/

    // Count the number of ones and transfer the bit stream to binary number
    /**Complete your Design**/

    /*******************************/
    // input2
    // Generate no repeated random number
    /**Complete your Design**/

    // Transfer the binary number to bit stream
    /**Complete your Design**/

    // Count the number of ones and transfer the bit stream to binary number
    /**Complete your Design**/

    /*******************************/
    // Multiplication on stochastic computing
    /**Complete your Design**/

    /*******************************/
    // Scaled addition on stochastic computing
    /**Complete your Design**/
    /*******************************/
}
