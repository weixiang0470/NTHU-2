#include <stdlib.h>
#include <time.h>
#include <cstdlib>
#include <string>
#include <iostream>
#include <math.h>
#include <algorithm>
#include <vector>

using namespace std;

int* error_injection(int input1, int bit_stream_length) {
    /*******************************/
    // Generate no repeated random number
    /**Complete your Design**/

    /*******************************/
    // Transfer the binary number to bit stream
    /**Complete your Design**/

    /*******************************/
    // Count the number of ones and transfer the bit stream to binary number
    /**Complete your Design**/

    /*******************************/
    // Flipping some bits randomly
    /**Complete your Design**/

    /*******************************/
    // Count the number of ones after attacking and transfer the bit stream to binary number
    /**Complete your Design**/
    /*******************************/
}
